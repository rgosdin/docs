AV Touch
========

An example on using AVFoundation on iOS devices. This allows a developer to access playing audio and accessing audio data from their application.

![Hove View](Screenshots/screenshot-1.png)

Build Requirements
-------

Xamarin.iOS 7.0, Xcode 5.0 and later

Related Links
-------

- [Original sample](http://developer.apple.com/library/ios/#samplecode/avTouch/Introduction/Intro.html)

License
-------

Xamarin port changes are released under the MIT license.

Authors
-------

Ported to Xamarin.iOS by Miguel de Icaza/Mykyta Bondarenko
