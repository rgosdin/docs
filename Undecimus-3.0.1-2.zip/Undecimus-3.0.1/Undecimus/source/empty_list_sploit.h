#ifndef empty_list_sploit_h
#define empty_list_sploit_h
#import <stdbool.h>

bool vfs_sploit(void);

#endif
