//
//  panic.h
//  Undecimus
//
//  Created by Pwn20wnd on 4/20/19.
//  Copyright © 2019 Pwn20wnd. All rights reserved.
//

#ifndef panic_h
#define panic_h

#include <stdio.h>

void do_kalloc_crash(void);

#endif /* panic_h */
