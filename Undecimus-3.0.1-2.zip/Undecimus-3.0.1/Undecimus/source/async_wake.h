#ifndef async_wake_h
#define async_wake_h

#include <stdio.h>

bool async_wake_go(void);

#endif /* async_wake_h */
