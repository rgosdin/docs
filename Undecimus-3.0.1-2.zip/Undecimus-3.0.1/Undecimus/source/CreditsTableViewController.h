//
//  CreditsTableViewController.h
//  Undecimus
//
//  Created by Pwn20wnd on 9/14/18.
//  Copyright © 2018 - 2019 Pwn20wnd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CreditsTableViewController : UITableViewController

+ (NSURL *)getURLForUserName:(NSString *)userName;

@end
