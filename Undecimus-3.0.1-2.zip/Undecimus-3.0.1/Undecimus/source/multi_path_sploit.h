#ifndef multi_path_sploit_h
#define multi_path_sploit_h

bool mptcp_go(void);

#endif
