#pragma once

int unlocknvram(void);
int locknvram(void);

