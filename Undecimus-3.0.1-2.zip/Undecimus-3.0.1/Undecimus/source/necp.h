#ifndef necp_h
#define necp_h

#include <stdio.h>

int necp_die(void);

#endif /* necp_h */
